import React from "react";

import "./ChannelIntro.scss";

function ChannelIntro() {
  return <div className="ChannelIntro"></div>;
}
export default ChannelIntro;
